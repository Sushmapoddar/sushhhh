package com.example.smartspend;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HelpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        // Find the TextView for the "Help" label
        TextView helpTextView = findViewById(R.id.textView);

        // Find the Spinner elements
        Spinner firstSpinner = findViewById(R.id.first);
        Spinner secondSpinner = findViewById(R.id.second);
        Spinner thirdSpinner = findViewById(R.id.third);
        Spinner fourthSpinner= findViewById(R.id.fourth);
        Spinner fifthSpinner=findViewById(R.id.fifth);
        Spinner sixthSpinner=findViewById(R.id.sixth);
        Spinner seventhSpinner=findViewById(R.id.seventh);
        Spinner eightSpinner=findViewById(R.id.eight);
        Spinner nineSpinner=findViewById(R.id.nine);
        Spinner tenSpinner=findViewById(R.id.tenth);



        // Create an array of currencies or items for the spinners
        String[] first = {"Item sdd" };


        // Create an ArrayAdapter and set it for each spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, first);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);



        firstSpinner.setAdapter(adapter);
        secondSpinner.setAdapter(adapter);
        thirdSpinner.setAdapter(adapter);
        fourthSpinner.setAdapter(adapter);
        fifthSpinner.setAdapter(adapter);
        sixthSpinner.setAdapter(adapter);
        seventhSpinner.setAdapter(adapter);
        eightSpinner.setAdapter(adapter);
        nineSpinner.setAdapter(adapter);
        tenSpinner.setAdapter(adapter);
        // ... (repeat for all 10 spinners)

        // Set up an OnItemSelectedListener for each spinner
        AdapterView.OnItemSelectedListener spinnerListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // Handle the selected item here
                String selectedCurrency = first[position];

            }


            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Do nothing here or provide a default behavior
            }
        };

        firstSpinner.setOnItemSelectedListener(spinnerListener);
        secondSpinner.setOnItemSelectedListener(spinnerListener);
        thirdSpinner.setOnItemSelectedListener(spinnerListener);
        fourthSpinner.setOnItemSelectedListener(spinnerListener);
        fifthSpinner.setOnItemSelectedListener(spinnerListener);
        sixthSpinner.setOnItemSelectedListener(spinnerListener);
        seventhSpinner.setOnItemSelectedListener(spinnerListener);
        eightSpinner.setOnItemSelectedListener(spinnerListener);
        nineSpinner.setOnItemSelectedListener(spinnerListener);
        tenSpinner.setOnItemSelectedListener(spinnerListener);
        // ... (repeat for all 10 spinners)

        // Add a click listener to the "Help" TextView
        helpTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the click event on the "Help" TextView
                Toast.makeText(HelpActivity.this, "Help clicked!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}