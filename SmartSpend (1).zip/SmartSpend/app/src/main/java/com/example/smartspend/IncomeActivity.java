package com.example.smartspend;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.example.smartspend.databinding.ActivityExpenseBinding;
import com.example.smartspend.databinding.ActivityIncomeBinding;

import java.util.Calendar;

public class IncomeActivity extends AppCompatActivity {
    ActivityIncomeBinding binding;
    private EditText editTextDate;
    private EditText editTextAmount;
    private EditText editTextTitle;
    private Button buttonAddIncome;
    @SuppressLint({"MissingInflatedId", "WrongViewCast"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityIncomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        editTextDate = findViewById(R.id.ed);
        editTextAmount = findViewById(R.id.editTextAmount);
        editTextTitle = findViewById(R.id.editTextTitle);
        buttonAddIncome = findViewById(R.id.buttonAddIncome);


        editTextDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog();
            }
        });

        buttonAddIncome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve the text from EditText fields
                String date = editTextDate.getText().toString();
                String amount = editTextAmount.getText().toString();
                String title = editTextTitle.getText().toString();

                // You can now use the data for further processing
                String message = "Date: " + date +
                        "\nAmount: " + amount +
                        "\nTitle: " + title ;

                // For demonstration, display the input in a toast message
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showDatePickerDialog() {
        final Calendar c = Calendar.getInstance();
        int y = c.get(Calendar.YEAR);
        int m = c.get(Calendar.MONTH);
        int d = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                String selectedDate = dayOfMonth + "/" + (month + 1) + "/" + year;
                editTextDate.setText(selectedDate);
            }
        }, y, m, d);
        datePickerDialog.show();
    }
}