package com.example.smartspend;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class NetBalanceActivity extends AppCompatActivity {

    private Button transactionButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_netbalance);

        transactionButton = findViewById(R.id.transactionbtn);

        transactionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Use an Intent to start the LogicActivity
                Intent intent;
                intent = new Intent(NetBalanceActivity.this, TransactionActivity.class);
                startActivity(intent);
            }
        });
    }
}
