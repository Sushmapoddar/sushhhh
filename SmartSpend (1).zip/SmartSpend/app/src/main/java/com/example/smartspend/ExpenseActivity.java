package com.example.smartspend;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.example.smartspend.databinding.ActivityExpenseBinding;

import java.util.Calendar;
import java.util.UUID;

public class ExpenseActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener
{
    ActivityExpenseBinding binding;
    private EditText editTextDate;
    private EditText editTextAmount;
    private EditText editTextCategory;
    private EditText editTextTitle;
    private Button buttonAddExpense;
    private Spinner spinner;
    private String expenseId;
    private String title;
    private String category;
    private int amount;

    @SuppressLint({"MissingInflatedId", "WrongViewCast"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityExpenseBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Spinner spinner = findViewById(R.id.editTextCategory);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.selectitems, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        editTextDate = findViewById(R.id.ed);
        editTextAmount = findViewById(R.id.editTextAmount);
        editTextTitle = findViewById(R.id.editTextTitle);
        buttonAddExpense = findViewById(R.id.buttonAddExpense);


        editTextDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog();
            }
        });



        buttonAddExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve the text from EditText fields
                String expenseId= UUID.randomUUID().toString();
                String date = editTextDate.getText().toString();
                String amount = editTextAmount.getText().toString();
                String category = editTextCategory.getText().toString();
                String title = editTextTitle.getText().toString();

                // You can now use the data for further processing
                String message = "Date: " + date +
                        "\nAmount: " + amount +
                        "\nCategory: " + category +
                        "\nTitle: " + title ;

                // For demonstration, display the input in a toast message
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showDatePickerDialog() {
        final Calendar c = Calendar.getInstance();
        int y = c.get(Calendar.YEAR);
        int m = c.get(Calendar.MONTH);
        int d = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                String selectedDate = dayOfMonth + "/" + (month + 1) + "/" + year;
                editTextDate.setText(selectedDate);
            }
        }, y, m, d);
        datePickerDialog.show();


        ExpenseModel expenseModel=new ExpenseModel(expenseId,title,category,Long.parseLong(String.valueOf(amount)));

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(),text,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
