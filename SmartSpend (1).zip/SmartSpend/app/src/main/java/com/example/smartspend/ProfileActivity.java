package com.example.smartspend;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    private EditText editName, editMail, editMobileNo, editBalance, editPassword;
    private Button buttonEditProfile;
    private ImageView myImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        editName = findViewById(R.id.editname);
        editMail = findViewById(R.id.editmail);
        editMobileNo = findViewById(R.id.editTextmobile);
        editBalance = findViewById(R.id.editTextbalance);
        editPassword = findViewById(R.id.editTextpassword);
        buttonEditProfile = findViewById(R.id.buttonEditProfile);
        myImageView = findViewById(R.id.my_image_view);

        buttonEditProfile.setOnClickListener(view -> {
            String name = editName.getText().toString().trim();
            String email = editMail.getText().toString().trim();
            String mobileNo = editMobileNo.getText().toString().trim();
            String balance = editBalance.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty() || mobileNo.isEmpty() || balance.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill all the fields", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Profile Updated Successfully", Toast.LENGTH_SHORT).show();
            }
        });
    }
}