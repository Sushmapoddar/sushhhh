package com.example.smartspend;

public class ExpenseModel {
    private String expenseId;
    private String title;
    private String category;
    private long amount;

    public ExpenseModel() {
    }

    public ExpenseModel(String expenseId, String title, String category, long amount) {
        this.expenseId = expenseId;
        this.title = title;
        this.category = category;
        this.amount = amount;
    }

    public String getExpenseId() {
        return expenseId;
    }

    public void setExpenseId(String expenseId) {
        this.expenseId = expenseId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }
}