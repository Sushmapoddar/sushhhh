package com.example.smartspend;

import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.smartspend.databinding.ActivityMainBinding;


public class TransactionActivity extends AppCompatActivity {
    ActivityMainBinding binding;
    private Object IncomeActivity;
    private Button btn_income;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Button addincomeButton=findViewById(R.id.btn_income);
        addincomeButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent;
                intent = new Intent(TransactionActivity.this,IncomeActivity.class);
                startActivity(intent);
            }
        });

        Button addexpenseButton=findViewById(R.id.addexpense);
        addexpenseButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent;
                intent = new Intent(TransactionActivity.this,ExpenseActivity.class);
                startActivity(intent);

            }
        });

    }
}